var browsersync = require('browser-sync');
var gulp = require('gulp');
var express = require('express');

var bs = browsersync.create();
var app = express();
app.use('/',express.static('public'));


//menu url

app.get('/menu',function(request,response){
	response.sendFile(__dirname + "/data/menu.json");
});

//country url
app.get('/country',function(request,response){
	response.sendFile(__dirname + "/data/country.json");
});

//browser sync task
gulp.task('browser-sync',function(){
	bs.init({
		proxy : {
			target : "localhost:3000"
		},
		browser : "chrome"	
	});
});
gulp.task('default',['browser-sync'],function(){
	var sarver = app.listen(3000,function(){
		console.log("sarver started at port 3000");
	});
	gulp.watch("public/*.html").on('change',bs.reload);
});

