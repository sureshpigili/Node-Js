function signinalert() {
    var firstname = prompt("Please enter your firstname");
    var lastname = prompt("Please enter your lastname");
    }

    
